import sqlite3
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import rental  # noqa: E402


@pytest.fixture
def conn():
    """Fresh in-memory database with sample data for every test."""
    c = rental.get_connection(":memory:")
    rental.init_db(c)
    yield c
    c.close()


def test_rental_days_same_day_counts_as_one():
    assert rental.rental_days("2025-11-10", "2025-11-10") == 1
    assert rental.rental_days("2025-11-10", "2025-11-13") == 3


def test_foreign_keys_are_enforced(conn):
    with pytest.raises(sqlite3.IntegrityError):
        conn.execute(
            "INSERT INTO RentalOrder (start_date, status, customer_id) "
            "VALUES ('2025-11-01', 'active', 999)"
        )


def test_lost_items_reduce_stock(conn):
    # Bike Lock: 6 in total, 1 reported lost in the sample data
    assert rental.get_available_quantity(conn, 5) == 5


def test_borrow_creates_order_and_reduces_stock(conn):
    order_id = rental.borrow_item(conn, 1, 1, 2, today="2025-12-01")
    assert rental.get_active_order_id(conn, 1) == order_id
    assert rental.get_available_quantity(conn, 1) == 3


def test_cannot_borrow_more_than_available(conn):
    with pytest.raises(rental.RentalError):
        rental.borrow_item(conn, 1, 2, 99)


def test_returning_item_not_in_order_raises(conn):
    rental.borrow_item(conn, 1, 1, 1)
    with pytest.raises(rental.RentalError):
        rental.return_item(conn, 1, 3)


def test_last_return_closes_order_and_bills_all_days(conn):
    order_id = rental.borrow_item(conn, 2, 1, 2, today="2025-12-01")
    closed = rental.return_item(conn, 2, 1, today="2025-12-04")
    assert closed
    receipt = rental.build_receipt(conn, order_id)
    assert "TOTAL: 600 NOK" in receipt  # 2 bikes × 100 NOK × 3 days
